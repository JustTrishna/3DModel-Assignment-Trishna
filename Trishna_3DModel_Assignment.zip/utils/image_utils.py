
import cv2
import numpy as np
from rembg import remove
import os

def clean_image_bg(image_path, save_to):
    # Load the input image
    original = cv2.imread(image_path)

    # Remove background using rembg (simple way to focus on the object)
    with open(image_path, 'rb') as img_file:
        img_data = img_file.read()
    output_data = remove(img_data)

    output_path = os.path.join(save_to, 'object_only.png')
    with open(output_path, 'wb') as out_file:
        out_file.write(output_data)

    print(f"Cleaned image saved at {output_path}")
    # Optional: Use this cleaned image for 3D model generation.
