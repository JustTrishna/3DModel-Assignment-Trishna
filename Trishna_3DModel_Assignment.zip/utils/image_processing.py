
import cv2
import numpy as np
from rembg import remove

def process_image(input_image_path, output_directory):
    # Load the image
    img = cv2.imread(input_image_path)
    
    # Optionally, remove the background using rembg (for better 3D generation)
    with open(input_image_path, 'rb') as input_file:
        input_data = input_file.read()
    output_data = remove(input_data)
    processed_image_path = os.path.join(output_directory, 'processed_image.png')
    
    with open(processed_image_path, 'wb') as output_file:
        output_file.write(output_data)

    print(f"Image processed and saved to {processed_image_path}")
    # Add logic for 3D object generation from the processed image here
