
import os
import argparse
from utils.image_utils import clean_image_bg
from utils.model_generator import text_prompt_to_model

def main():
    parser = argparse.ArgumentParser(description="Generate a 3D model from an image or text description.")
    parser.add_argument('--input', type=str, required=True, help="Path to image or text prompt")
    parser.add_argument('--output', type=str, required=True, help="Directory to save 3D model")
    args = parser.parse_args()

    if args.input.endswith(('.jpg', '.png')):
        print("Image input detected. Starting processing...")
        clean_image_bg(args.input, args.output)
    else:
        print("Text prompt detected. Generating model...")
        text_prompt_to_model(args.input, args.output)

if __name__ == "__main__":
    main()
