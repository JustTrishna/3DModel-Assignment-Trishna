
# Simple 3D Model Generator from Text or Image

## Overview

This is a basic Python-based prototype that accepts either an image (like a toy, chair, etc.) or a short text prompt, and produces a basic 3D model in `.obj` format.

## Why I Built This

I wanted to explore how text or photo inputs could be turned into 3D models using simple Python tools. I used background removal to isolate the object and basic geometry to mock a 3D shape.

## Tools & Libraries Used

- **OpenCV**: For image reading
- **rembg**: To remove image background
- **Standard Python I/O**: For saving .obj files

## How to Run

```bash
# Activate virtual environment
python -m venv env
source env/bin/activate  # For Windows use: env\Scripts\activate

# Install required packages
pip install -r requirements.txt

# For image input
python main.py --input input/chair.jpg --output output

# For text prompt
python main.py --input "A simple round table" --output output
```

## Output

- The result will be a `.obj` file saved in the output folder.
- This can be opened in 3D viewers like Blender or MeshLab.

## Notes

This is a mock prototype — text-based generation here is symbolic. In real projects, libraries like [Shap-E](https://github.com/openai/shap-e) or DreamFusion would be used.

---

*Created as part of a learning assignment using open-source tools.*
